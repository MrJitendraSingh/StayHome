package com.example.stayhome.home.dataclass

class ViewData(var image : Int, var title: String,var location : String,var price : String,var indexs : Int, var state:Int ?= null, var st : Boolean= false){

//    var title: String ?= null
//    var image : Int ?= null
//    var location : String ?= null
//    var price : String ?= null
//    var index : Int ?= null

}