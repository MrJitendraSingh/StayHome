package com.example.stayhome.home.dataclass

data class CategoryData(var image : Int, var name : String){
    var index : Int ?= null


}
