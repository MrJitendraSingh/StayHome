package com.example.stayhome.home.dataclass

data class ShopData(var name: String, var total: String, var date: String, var time: String){

}
